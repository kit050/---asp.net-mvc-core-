﻿namespace WebApplication3
{
    internal interface IDirectorysRepository
    {
    }
}